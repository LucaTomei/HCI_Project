# User Interaction - TODO

- [ ] Handle button "Fine" in product keyboard
- [ ] Handle "Visualizza Carrello"
- [ ] In dealer_persistence.json add other infos like telegram group name, ...
- [ ] Check if shopping cart is empty
- [ ] get_original_product_details <--- pass token