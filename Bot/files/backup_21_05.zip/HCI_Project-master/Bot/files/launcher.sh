#!/bin/sh
cd /home/pi/HCI_Project/Bot

/usr/bin/python3 bot.py