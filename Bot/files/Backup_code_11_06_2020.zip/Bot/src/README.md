# Content of this folder

- **Dealer_Interaction**: Handlers for interaction between bot and Dealer
- **User_Interaction**: Handlers for interaction between bot and User


## TODO
 - [ ] Delete all messages in chat: Write function that retrieve all user chat data and delete all mesages (read policy on [Policies](shorturl.at/uTVX0))