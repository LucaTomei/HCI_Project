#!/bin/sh
cd /home/pi/HCI_Project/Bot/src

/usr/bin/python3 bot.py