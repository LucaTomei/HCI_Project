# Content of this folder

- **src**: Bot source code
- **files**: Useful files for installing the bot as a daemon and requirements for installing used python libraries.
