# Dealer Interaction Activities

<h2>First Task:</h2>
<p align="center">
  <img src="files/screenshot/photo_2020-04-29 17.53.20.jpeg" />
</p>

Done? | Yes/No
:---:| ---
✅| Yes
⬜️| No

---

<h2>Second Task:</h2>

<!-- <p>After creating the list by clicking the buttons, the bot sends a token.</p> -->

<p align="center">
  <img src="files/screenshot/photo_2020-04-29 17.53.22.jpeg" />
</p>

Done? | Yes/No
:---:| ---
✅| Yes
⬜️|	No

---

<h2>Third Task: </h2>

<p align="center">
  <img src="files/screenshot/photo_2020-04-29 17.53.24.jpeg" />
</p>

Done? | Yes/No
:---:| ---
✅| Yes
⬜️|	No

---

<h2>Fourth Task:</h2>

<p align="center">
  <img src="files/screenshot/photo_2020-04-29 17.53.25.jpeg" />
</p>

Done? | Yes/No
:---:| ---
⬜️| Yes
✅| No

---

<h2>Fifth Task:</h2>

<p align="center">
  <img src="files/screenshot/photo_2020-04-29 17.53.26.jpeg" />
</p>

Done? | Yes/No
:---:| ---
⬜️| Yes
✅| No

---

<h2>Sixth Task:</h2>

<p align="center">
  <img src="files/screenshot/photo_2020-04-29 17.53.29.jpeg" />
</p>

Done? | Yes/No
:---:| ---
⬜️| Yes
✅| No

---

## Tasks & Notes

- [ ] Differentiate articles based on categories entered by a user
- [ ] Bot: Showcase your merchandise: Which category do you want to fill?
    - [ ] The buttons inserted in the previous phase appear
- [ ] User clicks one of the buttons
- [ ] Bot: Put a sub category of your categories. (Bakery: Loaves of bread, rolls, pizza, ...) (Further macro subdivision with list of foods)
    - [ ] Bot sends food list for that category
- [ ] User in this way click on the button and create his virtual showcase 
- [ ] After creating the list by clicking the buttons, the bot sends a token. 
